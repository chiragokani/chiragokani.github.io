%% Demonstration of spherical Bessel, Neumann, and Hankel functions

% Included in this package is the derivative of the Hankel functions of the 
% second kind, dhankelh2, but it is not demonstrated here.

clear all
close all

%% Prepare the plot for the demo
r = linspace(0,4*pi,1000); %I am using r as the input argument for these functions

%Adjust size, nothing important here
set(groot,'DefaultAxesFontSize', 21) 
set(groot,'DefaultLineLineWidth', 2)
set(groot,'DefaultAxesLineWidth', 2)
%set(groot, 'defaultFigureUnits', 'centimeters', 'defaultFigurePosition', [0 0 29 11]);

%% Spherical Bessel functions

%For spherical Bessel functions, use sphbesselj(n,r)

%Note that this is equivalent to real(sphhankelh1(n,r) =
%real(sphhankelh2(n,r)

%% Spherical Neumann functions

%For spherical Neumann functions, use sphneumannn(n,r))

%Note that this is equivalent to imag(sphhankelh1(n,r)) = -imag(sphhankelh2(n,r))

%% Spherical Hankel functions

%For spherical Hankel functions of the first kind, use sphhankelh1(n,r))

%For spherical Hankel functions of the second kind, use sphhankelh2(n,r))

%Since the spherical Hankel functions of the second kind correspond to
%outgoing waves in the e^{j(\omega t-kx)} convention, it is more often used than the spherical Hankel functions 
% of the first kind, which correspond to incoming waves.

%In the e^{i(kx - \omega t)} convention, it is more often used than the spherical Hankel functions 
% of the first kind, which correspond to outgoing waves.

%% Demo

for n = 0:3 %will plot the first three orders of each of the functions

    y1 = sphbesselj(n,r); %these are the spherical Bessel functions
    
    y2 = sphneumannn(n,r); %these are the spherical Neumann functions

    y3 = real(sphhankelh2(n,r)); %Here, the spherical Hankel function of the 
    % second kind is used to generate the spherical Bessel functions

    y4 = -imag(sphhankelh2(n,r)); %Here, the spherical Hankel function of the 
    % second kind is used to generate the spherical Neumann functions

%% Plots

    plot(r,y1,'-b'); %plot of spherical Bessel functions
    hold on
    plot(r,y2,'-r'); %plot of spherical Neumann functions  
    hold on
    plot(r,y3,'--g'); %plot of spherical Bessel functions using Hankel functions
    hold on
    plot(r,y4,'--y'); %plot of spherical Neumann functions using Hankel functions
    hold on
end

xlim([0,max(r)]);
ylim([-1,1]);
xlabel('$r$','interpreter','latex'); % x axis labels
l = legend('$j_n(r)$','$n_n(r)$','$j_n(r) = $ Re $ h_n^{(2)}(r)$','$n_n(r) = $ $-$Im $h_n^{(2)}(r)$','Interpreter','latex');
legend('Location','bestoutside')
title('Demo of spherical Bessel, Neumann, and Hankel functions','Interpreter','latex')