function [X] = dhankelh2(n,x)
%derivative of hankel function
X = (n./x .* sphhankelh2(n,x) - sphhankelh2(n+1,x)); %equation 2 from 'Properties of...'
end
