function [X] = sphneumannn(n,x)
%sphneumannn(n,x): calculates spherical Neumann function by 
%relation with cylindrical Hankel function H

X = sqrt(pi./(2.*x)).*bessely(n+0.5,x);
%X = real((-1)^(n+1)*sqrt(pi./(2.*x)).*besselh(-n-0.5, 2, x));
end
