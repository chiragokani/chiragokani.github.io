function [X] = sphhankelh1(n,x)
%sphhankelh2(n,x): calculates spherical Hankel function by relation 
% with cylindrical hankel function H
X = (sqrt(pi./(2.*x)).*besselh(n+0.5, 1, x));
end