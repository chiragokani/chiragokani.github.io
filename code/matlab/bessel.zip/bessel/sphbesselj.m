function [X] = sphbesselj(n,x)
%sphbesselj(n,x): calculates spherical Bessel function of first kind j_n(x)
%by relation with cylindrical Bessel function
X = real(sqrt(pi./(2.*x)).*besselj(n + 0.5, x));
end

