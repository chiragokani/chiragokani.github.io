function [X] = sphneumannn(n,x)
%sphneumannn(n,x): calculates spherical Neumann function function by 
%relation with cylindrical Hankel function H

X = real((-1)^(n+1)*sqrt(pi./(2.*x)).*besselh(-n-0.5, 2, x));
end
